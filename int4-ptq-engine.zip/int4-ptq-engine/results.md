| precision | val perplexity | linear-layer size | compression vs FP32 | latency (ms/fwd) |
|---|---|---|---|---|
| FP32 | 31.078 | 3072.0 KB | 1.00x | 46.473 |
| INT8 | 31.078 | 960.0 KB | 3.20x | 49.519 |
| INT4 | 31.083 | 576.0 KB | 5.33x | 52.691 |

Per-layer mean |dequant error| (INT4):

| layer | mean abs error |
|---|---|
| blocks.0.attn.qkv_proj | 0.002968 |
| blocks.0.attn.out_proj | 0.002898 |
| blocks.0.mlp.fc_in | 0.003259 |
| blocks.0.mlp.fc_out | 0.001878 |
| blocks.1.attn.qkv_proj | 0.002963 |
| blocks.1.attn.out_proj | 0.002855 |
| blocks.1.mlp.fc_in | 0.003251 |
| blocks.1.mlp.fc_out | 0.001878 |
| blocks.2.attn.qkv_proj | 0.002948 |
| blocks.2.attn.out_proj | 0.002847 |
| blocks.2.mlp.fc_in | 0.003277 |
| blocks.2.mlp.fc_out | 0.001884 |
| blocks.3.attn.qkv_proj | 0.002971 |
| blocks.3.attn.out_proj | 0.002851 |
| blocks.3.mlp.fc_in | 0.003306 |
| blocks.3.mlp.fc_out | 0.001919 |
