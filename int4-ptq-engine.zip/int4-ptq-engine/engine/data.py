"""
Synthetic token-sequence generator.

The quantization engine doesn't care what the model was trained on -- what
matters is that there is a real train/val split and a real loss signal, so
that FP16 vs INT8 vs INT4 perplexity numbers are meaningful instead of
trivially identical (which they would be on pure noise).

To keep the project fully self-contained (no dataset download, no
copyrighted text), we generate a small synthetic "language": a vocabulary of
tokens emitted by a fixed Markov chain. This gives the model learnable
structure (some tokens reliably follow others) while remaining 100%
reproducible and license-free.
"""

import torch


class SyntheticLanguage:
    def __init__(self, vocab_size: int = 64, seed: int = 1337):
        self.vocab_size = vocab_size
        g = torch.Generator().manual_seed(seed)

        # Random but fixed transition matrix, sharpened with a temperature
        # so some transitions are much more likely than others (= structure
        # a transformer can actually learn).
        raw = torch.rand(vocab_size, vocab_size, generator=g)
        self.transition = torch.softmax(raw * 6.0, dim=-1)

    def sample(self, n_tokens: int, seed: int) -> torch.Tensor:
        g = torch.Generator().manual_seed(seed)
        tokens = torch.zeros(n_tokens, dtype=torch.long)
        tokens[0] = torch.randint(0, self.vocab_size, (1,), generator=g)
        for i in range(1, n_tokens):
            probs = self.transition[tokens[i - 1]]
            tokens[i] = torch.multinomial(probs, 1, generator=g)
        return tokens


def make_splits(vocab_size: int, block_size: int, train_tokens: int, val_tokens: int,
                 seed: int = 1337):
    lang = SyntheticLanguage(vocab_size=vocab_size, seed=seed)
    train_stream = lang.sample(train_tokens, seed=seed + 1)
    val_stream = lang.sample(val_tokens, seed=seed + 2)
    return train_stream, val_stream


def get_batch(stream: torch.Tensor, block_size: int, batch_size: int, generator: torch.Generator):
    max_start = stream.size(0) - block_size - 1
    starts = torch.randint(0, max_start, (batch_size,), generator=generator)
    x = torch.stack([stream[s:s + block_size] for s in starts])
    y = torch.stack([stream[s + 1:s + block_size + 1] for s in starts])
    return x, y
