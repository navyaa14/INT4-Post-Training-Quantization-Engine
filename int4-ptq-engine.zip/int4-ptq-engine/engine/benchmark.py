"""
End-to-end benchmark: train a tiny GPT, then compare FP32 (baseline),
INT8-PTQ, and INT4-PTQ on:
  * validation perplexity (quality)
  * Linear-layer storage size in bytes (compression)
  * forward-pass latency (speed -- note: a *dequant-then-matmul* simulation,
    see README for why this does not show INT4 speedups on stock CPU PyTorch)

Run with:  python -m engine.benchmark
"""

import argparse
import copy
import time

import torch

from .data import make_splits, get_batch
from .model import GPTConfig, TinyGPT
from .quant import quantize_model, fp32_linear_bytes, engine_linear_bytes, QuantLinear


def train(model, train_stream, cfg, steps, batch_size, lr, device, log_every=50):
    model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    g = torch.Generator().manual_seed(0)
    model.train()
    for step in range(steps):
        x, y = get_batch(train_stream, cfg.block_size, batch_size, g)
        x, y = x.to(device), y.to(device)
        _, loss = model(x, y)
        opt.zero_grad()
        loss.backward()
        opt.step()
        if log_every and step % log_every == 0:
            print(f"  step {step:4d} | train loss {loss.item():.4f}")
    return model


@torch.no_grad()
def evaluate_perplexity(model, val_stream, cfg, batch_size, n_batches, device):
    model.eval()
    g = torch.Generator().manual_seed(123)  # fixed eval batches -> fair comparison across precisions
    losses = []
    for _ in range(n_batches):
        x, y = get_batch(val_stream, cfg.block_size, batch_size, g)
        x, y = x.to(device), y.to(device)
        _, loss = model(x, y)
        losses.append(loss.item())
    mean_loss = sum(losses) / len(losses)
    return float(torch.exp(torch.tensor(mean_loss)))


@torch.no_grad()
def measure_latency(model, cfg, batch_size, device, n_warmup=5, n_iters=30):
    model.eval()
    x = torch.randint(0, cfg.vocab_size, (batch_size, cfg.block_size), device=device)
    for _ in range(n_warmup):
        model(x)
    if device == "cuda":
        torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(n_iters):
        model(x)
    if device == "cuda":
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - start
    return (elapsed / n_iters) * 1000.0  # ms/forward pass


def per_layer_error_report(fp32_model, quant_model):
    """Mean abs dequant error for every QuantLinear, vs. the matching FP32 weight."""
    fp32_linears = dict(fp32_model.named_modules())
    rows = []
    for name, module in quant_model.named_modules():
        if isinstance(module, QuantLinear):
            original_weight = fp32_linears[name].weight.data
            rows.append((name, module.quantization_error(original_weight)))
    return rows


def run(args):
    device = "cuda" if (torch.cuda.is_available() and not args.cpu) else "cpu"
    print(f"device: {device}")

    cfg = GPTConfig(vocab_size=args.vocab_size, block_size=args.block_size,
                     n_layer=args.n_layer, n_head=args.n_head, n_embd=args.n_embd)
    train_stream, val_stream = make_splits(cfg.vocab_size, cfg.block_size,
                                            train_tokens=args.train_tokens,
                                            val_tokens=args.val_tokens)

    torch.manual_seed(0)
    model = TinyGPT(cfg)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"model: {n_params:,} params, {cfg.n_layer} layers, {cfg.n_embd} dim")

    print("\ntraining FP32 baseline...")
    train(model, train_stream, cfg, steps=args.steps, batch_size=args.batch_size,
          lr=args.lr, device=device)
    model.eval()

    fp32_model = copy.deepcopy(model)

    results = {}
    fp32_ppl = evaluate_perplexity(fp32_model, val_stream, cfg, args.batch_size, args.eval_batches, device)
    fp32_bytes = fp32_linear_bytes(fp32_model, exclude=args.exclude)
    fp32_latency = measure_latency(fp32_model, cfg, args.batch_size, device)
    results["FP32"] = dict(perplexity=fp32_ppl, linear_bytes=fp32_bytes, latency_ms=fp32_latency)

    for bits in (8, 4):
        qmodel = copy.deepcopy(model)
        quantize_model(qmodel, bits=bits, group_size=args.group_size, exclude=args.exclude)
        ppl = evaluate_perplexity(qmodel, val_stream, cfg, args.batch_size, args.eval_batches, device)
        qbytes = engine_linear_bytes(qmodel)
        latency = measure_latency(qmodel, cfg, args.batch_size, device)
        results[f"INT{bits}"] = dict(perplexity=ppl, linear_bytes=qbytes, latency_ms=latency)
        if bits == 4:
            error_rows = per_layer_error_report(fp32_model, qmodel)

    print("\n" + format_results_table(results))
    print("\nper-layer mean |dequant error| (INT4):")
    for name, err in error_rows:
        print(f"  {name:30s} {err:.6f}")

    if args.out:
        with open(args.out, "w") as f:
            f.write(format_results_table(results) + "\n\n")
            f.write("Per-layer mean |dequant error| (INT4):\n\n")
            f.write("| layer | mean abs error |\n|---|---|\n")
            for name, err in error_rows:
                f.write(f"| {name} | {err:.6f} |\n")
        print(f"\nwrote results to {args.out}")

    return results


def format_results_table(results: dict) -> str:
    fp32_bytes = results["FP32"]["linear_bytes"]
    lines = [
        "| precision | val perplexity | linear-layer size | compression vs FP32 | latency (ms/fwd) |",
        "|---|---|---|---|---|",
    ]
    for name, r in results.items():
        ratio = fp32_bytes / r["linear_bytes"]
        lines.append(
            f"| {name} | {r['perplexity']:.3f} | {r['linear_bytes'] / 1024:.1f} KB | "
            f"{ratio:.2f}x | {r['latency_ms']:.3f} |"
        )
    return "\n".join(lines)


def build_argparser():
    p = argparse.ArgumentParser(description="Train a tiny GPT and benchmark FP32 vs INT8 vs INT4 PTQ.")
    p.add_argument("--vocab_size", type=int, default=64)
    p.add_argument("--block_size", type=int, default=64)
    p.add_argument("--n_layer", type=int, default=4)
    p.add_argument("--n_head", type=int, default=4)
    p.add_argument("--n_embd", type=int, default=128)
    p.add_argument("--train_tokens", type=int, default=200_000)
    p.add_argument("--val_tokens", type=int, default=20_000)
    p.add_argument("--steps", type=int, default=400)
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--eval_batches", type=int, default=20)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--group_size", type=int, default=32)
    p.add_argument("--exclude", nargs="*", default=["head"],
                    help="substrings of layer names to keep in FP32 (default: output head)")
    p.add_argument("--cpu", action="store_true", help="force CPU even if CUDA is available")
    p.add_argument("--out", type=str, default="results.md")
    return p


if __name__ == "__main__":
    args = build_argparser().parse_args()
    run(args)
