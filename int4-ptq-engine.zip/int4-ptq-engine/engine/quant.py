"""
int4_ptq.engine.quant
======================

A small, from-scratch post-training quantization (PTQ) engine for
nn.Linear layers. No bitsandbytes / torch.ao / one-click quantization API
is used -- the math (scale + zero-point computation, group-wise
calibration, sub-byte packing/unpacking) is implemented directly so the
quality-vs-compression trade-offs are fully inspectable.

Supported precisions: INT8 and INT4 (unsigned, affine/asymmetric, per
output-channel + per-group). Weight-only "round-to-nearest" (RTN)
quantization -- the standard baseline algorithm used by production
toolkits (e.g. as the fallback path in AutoGPTQ/bitsandbytes) before more
elaborate calibration (GPTQ-style Hessian correction, AWQ-style activation
scaling) is layered on top.

Design choices, and why:
  * Per-group affine quantization (scale + zero-point per `group_size`
    contiguous input channels) instead of per-tensor: a single outlier
    weight in a per-tensor scheme blows up the scale for every other
    weight. Grouping bounds the damage to one group.
  * Weights are packed two-per-byte for INT4 so the *stored* tensor is
    genuinely 4 bits/weight (not just values that happen to fit in 0-15
    stored as int8) -- this is what actually gets measured in
    `engine_size_bytes()`.
  * Biases are kept in full precision. They are a tiny fraction of total
    parameters and quantizing them buys negligible memory savings for a
    measurable quality hit.
"""

from dataclasses import dataclass
from typing import Iterable, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class QuantConfig:
    bits: int = 4
    group_size: int = 64
    eps: float = 1e-8

    def __post_init__(self):
        if self.bits not in (4, 8):
            raise ValueError(f"Unsupported bit-width: {self.bits} (use 4 or 8)")
        if self.group_size % 2 != 0:
            raise ValueError("group_size must be even (required for INT4 packing)")


# --------------------------------------------------------------------------
# Low-level: calibration (scale / zero-point) + pack / unpack
# --------------------------------------------------------------------------

def compute_qparams(w_groups: torch.Tensor, bits: int, eps: float):
    """w_groups: [out_features, n_groups, group_size] -> per-group (scale, zero_point)."""
    qmax = 2 ** bits - 1
    w_min = w_groups.amin(dim=-1)
    w_max = w_groups.amax(dim=-1)
    w_max = torch.maximum(w_max, w_min + eps)  # avoid divide-by-zero on constant groups
    scale = (w_max - w_min) / qmax
    zero_point = torch.clamp(torch.round(-w_min / scale), 0, qmax)
    return scale, zero_point


def affine_quantize(w_groups: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor, bits: int):
    qmax = 2 ** bits - 1
    q = torch.round(w_groups / scale.unsqueeze(-1)) + zero_point.unsqueeze(-1)
    return torch.clamp(q, 0, qmax).to(torch.uint8)


def affine_dequantize(q: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
    return (q.float() - zero_point.unsqueeze(-1)) * scale.unsqueeze(-1)


def pack_uint4(q: torch.Tensor) -> torch.Tensor:
    """[..., L] uint8 values in [0,15], L even -> [..., L/2] uint8, 2 values/byte."""
    low = q[..., 0::2] & 0x0F
    high = q[..., 1::2] & 0x0F
    return (low | (high << 4)).to(torch.uint8)


def unpack_uint4(packed: torch.Tensor, length: int) -> torch.Tensor:
    low = packed & 0x0F
    high = (packed >> 4) & 0x0F
    out = torch.empty(*packed.shape[:-1], packed.shape[-1] * 2, dtype=torch.uint8, device=packed.device)
    out[..., 0::2] = low
    out[..., 1::2] = high
    return out[..., :length]


# --------------------------------------------------------------------------
# QuantLinear: drop-in replacement for nn.Linear
# --------------------------------------------------------------------------

class QuantLinear(nn.Module):
    def __init__(self, in_features: int, out_features: int, bias: Optional[torch.Tensor], cfg: QuantConfig):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.cfg = cfg

        pad = (-in_features) % cfg.group_size
        self.padded_in_features = in_features + pad
        self.n_groups = self.padded_in_features // cfg.group_size

        store_features = self.padded_in_features // 2 if cfg.bits == 4 else self.padded_in_features
        self.register_buffer("packed_weight", torch.zeros(out_features, store_features, dtype=torch.uint8))
        self.register_buffer("scale", torch.zeros(out_features, self.n_groups))
        self.register_buffer("zero_point", torch.zeros(out_features, self.n_groups))
        if bias is not None:
            self.register_buffer("bias", bias.clone())
        else:
            self.bias = None

    @classmethod
    def from_float(cls, linear: nn.Linear, cfg: QuantConfig) -> "QuantLinear":
        qlin = cls(linear.in_features, linear.out_features, linear.bias.data if linear.bias is not None else None, cfg)
        qlin.load_weight(linear.weight.data)
        return qlin

    def load_weight(self, weight: torch.Tensor):
        pad = self.padded_in_features - self.in_features
        w = F.pad(weight, (0, pad)) if pad else weight
        w_groups = w.view(self.out_features, self.n_groups, self.cfg.group_size)

        scale, zero_point = compute_qparams(w_groups, self.cfg.bits, self.cfg.eps)
        q = affine_quantize(w_groups, scale, zero_point, self.cfg.bits)
        q_flat = q.view(self.out_features, self.padded_in_features)

        packed = pack_uint4(q_flat) if self.cfg.bits == 4 else q_flat
        self.packed_weight.copy_(packed)
        self.scale.copy_(scale)
        self.zero_point.copy_(zero_point)

    def dequantize_weight(self) -> torch.Tensor:
        if self.cfg.bits == 4:
            q_flat = unpack_uint4(self.packed_weight, self.padded_in_features)
        else:
            q_flat = self.packed_weight
        q = q_flat.view(self.out_features, self.n_groups, self.cfg.group_size)
        w_hat = affine_dequantize(q, self.scale, self.zero_point)
        return w_hat.view(self.out_features, self.padded_in_features)[:, :self.in_features]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.linear(x, self.dequantize_weight(), self.bias)

    def engine_size_bytes(self) -> int:
        size = self.packed_weight.numel() * self.packed_weight.element_size()
        size += self.scale.numel() * 4 + self.zero_point.numel() * 4
        if self.bias is not None:
            size += self.bias.numel() * self.bias.element_size()
        return size

    def quantization_error(self, original_weight: torch.Tensor) -> float:
        return (self.dequantize_weight() - original_weight).abs().mean().item()

    def extra_repr(self) -> str:
        return f"in={self.in_features}, out={self.out_features}, bits={self.cfg.bits}, group_size={self.cfg.group_size}"


# --------------------------------------------------------------------------
# Model-level API
# --------------------------------------------------------------------------

def quantize_model(model: nn.Module, bits: int = 4, group_size: int = 64,
                    exclude: Iterable[str] = ()) -> nn.Module:
    """Replace every nn.Linear in `model` with a QuantLinear, in place.

    `exclude` is a set/list of substrings -- any module whose dotted name
    contains one of them is left untouched (commonly used to keep the
    output head in full precision, since it directly drives the loss).
    """
    cfg = QuantConfig(bits=bits, group_size=group_size)
    targets = []
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear) and not any(ex in name for ex in exclude):
            targets.append(name)

    for name in targets:
        *parent_path, leaf = name.split(".")
        parent = model
        for p in parent_path:
            parent = getattr(parent, p)
        original_linear = getattr(parent, leaf)
        setattr(parent, leaf, QuantLinear.from_float(original_linear, cfg))

    return model


def fp32_linear_bytes(model: nn.Module, exclude: Iterable[str] = ()) -> int:
    """Total bytes used by the nn.Linear weights+biases this engine would target,
    at full FP32 precision -- used as the baseline for compression-ratio reporting."""
    total = 0
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear) and not any(ex in name for ex in exclude):
            total += module.weight.numel() * module.weight.element_size()
            if module.bias is not None:
                total += module.bias.numel() * module.bias.element_size()
    return total


def engine_linear_bytes(model: nn.Module) -> int:
    """Total bytes used by every QuantLinear in `model`."""
    total = 0
    for module in model.modules():
        if isinstance(module, QuantLinear):
            total += module.engine_size_bytes()
    return total
