import torch
import torch.nn as nn

from engine.quant import (
    QuantConfig, QuantLinear, quantize_model,
    pack_uint4, unpack_uint4, fp32_linear_bytes, engine_linear_bytes,
)
from engine.model import GPTConfig, TinyGPT


def test_pack_unpack_roundtrip():
    torch.manual_seed(0)
    q = torch.randint(0, 16, (8, 40), dtype=torch.uint8)
    packed = pack_uint4(q)
    assert packed.shape == (8, 20)
    restored = unpack_uint4(packed, length=40)
    assert torch.equal(q, restored)


def test_int4_quantization_error_is_small():
    torch.manual_seed(0)
    lin = nn.Linear(128, 32, bias=True)
    qlin = QuantLinear.from_float(lin, QuantConfig(bits=4, group_size=32))
    err = qlin.quantization_error(lin.weight.data)
    weight_scale = lin.weight.data.abs().mean().item()
    # 4-bit RTN error should be a small fraction of the typical weight magnitude
    assert err < 0.15 * weight_scale


def test_int8_is_more_accurate_than_int4():
    torch.manual_seed(1)
    lin = nn.Linear(96, 24, bias=False)
    err4 = QuantLinear.from_float(lin, QuantConfig(bits=4, group_size=32)).quantization_error(lin.weight.data)
    err8 = QuantLinear.from_float(lin, QuantConfig(bits=8, group_size=32)).quantization_error(lin.weight.data)
    assert err8 < err4


def test_smaller_group_size_reduces_error_on_outlier_weights():
    """A single large outlier should hurt a coarse (large) group less precisely
    than... actually it hurts the *whole group* it sits in. Smaller groups
    contain the damage to fewer neighbouring weights, so the *mean* error
    across the row should drop as group_size shrinks."""
    torch.manual_seed(2)
    weight = torch.randn(4, 128) * 0.05
    weight[0, 0] = 5.0  # single severe outlier in row 0

    lin = nn.Linear(128, 4, bias=False)
    lin.weight.data.copy_(weight)

    err_coarse = QuantLinear.from_float(lin, QuantConfig(bits=4, group_size=128)).quantization_error(weight)
    err_fine = QuantLinear.from_float(lin, QuantConfig(bits=4, group_size=16)).quantization_error(weight)
    assert err_fine < err_coarse


def test_packed_storage_is_smaller_than_fp32():
    torch.manual_seed(0)
    lin = nn.Linear(256, 64, bias=True)
    qlin = QuantLinear.from_float(lin, QuantConfig(bits=4, group_size=64))
    fp32_bytes = lin.weight.numel() * 4
    assert qlin.engine_size_bytes() < fp32_bytes / 3  # >3x smaller despite scale/zero_point overhead


def test_quantize_model_replaces_all_linears_except_excluded():
    cfg = GPTConfig(vocab_size=16, block_size=16, n_layer=2, n_head=2, n_embd=32)
    model = TinyGPT(cfg)
    quantize_model(model, bits=4, group_size=16, exclude=["head"])

    n_quant = sum(isinstance(m, QuantLinear) for m in model.modules())
    n_plain_linear = sum(isinstance(m, nn.Linear) for m in model.modules())
    assert n_quant > 0
    assert n_plain_linear == 1  # only the excluded `head` should remain a plain nn.Linear


def test_quantize_model_forward_pass_runs():
    cfg = GPTConfig(vocab_size=16, block_size=16, n_layer=2, n_head=2, n_embd=32)
    model = TinyGPT(cfg)
    quantize_model(model, bits=4, group_size=16, exclude=["head"])
    x = torch.randint(0, 16, (2, 16))
    logits, _ = model(x)
    assert logits.shape == (2, 16, 16)
    assert torch.isfinite(logits).all()


def test_engine_bytes_smaller_than_fp32_bytes_for_full_model():
    cfg = GPTConfig(vocab_size=32, block_size=32, n_layer=2, n_head=2, n_embd=64)
    model = TinyGPT(cfg)
    baseline_bytes = fp32_linear_bytes(model, exclude=["head"])
    quantize_model(model, bits=4, group_size=32, exclude=["head"])
    quant_bytes = engine_linear_bytes(model)
    assert quant_bytes < baseline_bytes / 4  # close to the theoretical 8x before scale/zp overhead
